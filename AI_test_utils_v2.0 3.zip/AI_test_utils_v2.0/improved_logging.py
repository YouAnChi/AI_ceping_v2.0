import logging
import os
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
from datetime import datetime
import platform

def setup_improved_logging(app):
    """
    改进的日志配置方案，解决Windows系统权限问题
    
    主要改进：
    1. 使用TimedRotatingFileHandler替代RotatingFileHandler
    2. 添加文件锁检查和重试机制
    3. 支持多种日志存储策略
    4. 增强错误处理
    """
    
    # 获取日志目录
    log_dir = os.path.join(app.instance_path, 'logs')
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # 生成带时间戳的日志文件名
    timestamp = datetime.now().strftime('%Y%m%d')
    log_file = os.path.join(log_dir, f'app_{timestamp}.log')
    
    # 清除现有的处理器
    app.logger.handlers.clear()
    
    try:
        # 方案1：使用TimedRotatingFileHandler（推荐）
        # 按天轮转，保留30天的日志
        handler = TimedRotatingFileHandler(
            log_file,
            when='midnight',
            interval=1,
            backupCount=30,
            encoding='utf-8'
        )
        
        # 设置日志格式
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        handler.setLevel(logging.INFO)
        
        # 添加处理器
        app.logger.addHandler(handler)
        app.logger.setLevel(logging.INFO)
        
        # 记录初始化成功
        app.logger.info(f'改进日志系统初始化成功，日志文件: {log_file}')
        app.logger.info(f'操作系统: {platform.system()}')
        
        return True
        
    except Exception as e:
        # 如果文件日志失败，至少保证控制台日志可用
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        console_handler.setLevel(logging.INFO)
        app.logger.addHandler(console_handler)
        app.logger.setLevel(logging.INFO)
        
        app.logger.error(f'文件日志初始化失败，已切换到控制台日志: {str(e)}')
        return False

def setup_alternative_logging(app):
    """
    备选日志方案：使用单一文件 + 手动轮转
    适用于权限受限的环境
    """
    
    log_dir = os.path.join(app.instance_path, 'logs')
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # 使用固定文件名，避免轮转时的权限问题
    log_file = os.path.join(log_dir, 'app_current.log')
    
    # 清除现有处理器
    app.logger.handlers.clear()
    
    try:
        # 检查文件大小，如果超过限制则手动备份
        if os.path.exists(log_file):
            file_size = os.path.getsize(log_file)
            max_size = 10 * 1024 * 1024  # 10MB
            
            if file_size > max_size:
                # 手动备份
                backup_file = os.path.join(log_dir, f'app_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log')
                try:
                    os.rename(log_file, backup_file)
                except OSError:
                    # 如果重命名失败，尝试复制后删除
                    import shutil
                    shutil.copy2(log_file, backup_file)
                    open(log_file, 'w').close()  # 清空原文件
        
        # 使用普通FileHandler
        handler = logging.FileHandler(log_file, encoding='utf-8')
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        handler.setLevel(logging.INFO)
        
        app.logger.addHandler(handler)
        app.logger.setLevel(logging.INFO)
        
        app.logger.info(f'备选日志系统初始化成功，日志文件: {log_file}')
        return True
        
    except Exception as e:
        # 最后的备选方案：控制台日志
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        console_handler.setLevel(logging.INFO)
        app.logger.addHandler(console_handler)
        app.logger.setLevel(logging.INFO)
        
        app.logger.error(f'所有文件日志方案都失败，使用控制台日志: {str(e)}')
        return False

def setup_database_logging(app):
    """
    数据库日志方案：将日志存储到数据库中
    适用于文件系统权限严格受限的环境
    """
    from app.models import db
    
    class DatabaseLogHandler(logging.Handler):
        def __init__(self, app):
            super().__init__()
            self.app = app
        
        def emit(self, record):
            try:
                with self.app.app_context():
                    # 这里需要创建一个日志表来存储日志记录
                    # 由于当前项目没有日志表，这里只是示例
                    log_entry = {
                        'timestamp': datetime.fromtimestamp(record.created),
                        'level': record.levelname,
                        'message': record.getMessage(),
                        'module': record.module,
                        'function': record.funcName,
                        'line': record.lineno
                    }
                    # 实际实现需要创建对应的数据库表
                    pass
            except Exception:
                # 避免日志记录本身出错影响应用
                pass
    
    # 清除现有处理器
    app.logger.handlers.clear()
    
    # 添加数据库处理器
    db_handler = DatabaseLogHandler(app)
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    db_handler.setFormatter(formatter)
    db_handler.setLevel(logging.INFO)
    
    # 同时保留控制台输出
    console_handler = logging.StreamHandler()
    console_handler.setFormatter(formatter)
    console_handler.setLevel(logging.INFO)
    
    app.logger.addHandler(db_handler)
    app.logger.addHandler(console_handler)
    app.logger.setLevel(logging.INFO)
    
    app.logger.info('数据库日志系统初始化成功')
    return True