from datetime import datetime
from app import db, login_manager
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

# Flask-Login 用户加载回调函数
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, index=True, nullable=False)
    email = db.Column(db.String(120), unique=True, index=True, nullable=True) # 邮箱可以为空
    password_hash = db.Column(db.String(128), nullable=False)
    registered_on = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    is_admin = db.Column(db.Boolean, default=False) # 新增管理员标识字段

    # 与 UserActivityLog 建立关系
    activities = db.relationship('UserActivityLog', backref='user', lazy='dynamic')

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f'<User {self.username}>'

class UserActivityLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    action = db.Column(db.String(128), nullable=False) # 例如 'login', 'logout', 'register', 'view_function1'
    details = db.Column(db.Text, nullable=True) # 存储额外信息，如页面URL，操作结果等
    ip_address = db.Column(db.String(45), nullable=True) # 记录用户IP地址

    def __repr__(self):
        return f'<Activity {self.action} by User {self.user_id} at {self.timestamp}>'

class ButtonClickLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True) # 允许匿名用户点击，或者根据需求设为nullable=False
    button_name = db.Column(db.String(128), nullable=False) # 例如 'function1_submit', 'function3_submit', 'function4_submit'
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)

    def __repr__(self):
        return f'<ButtonClickLog {self.button_name} by User {self.user_id} at {self.timestamp}>'

class DataProcessingStats(db.Model):
    """数据处理统计表，用于记录Excel数据处理的统计信息"""
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)  # 关联用户
    processing_type = db.Column(db.String(64), nullable=False)  # 处理类型：'zhiBiao_achieve', 'TQ_tools', 'AI_evaluation'
    file_name = db.Column(db.String(256), nullable=True)  # 处理的文件名
    file_path = db.Column(db.String(512), nullable=True)  # 文件路径
    rows_processed = db.Column(db.Integer, nullable=False)  # 处理的数据行数
    processing_details = db.Column(db.Text, nullable=True)  # 处理详情（JSON格式存储额外信息）
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)  # 处理时间
    duration_seconds = db.Column(db.Float, nullable=True)  # 处理耗时（秒）
    status = db.Column(db.String(32), nullable=False)  # 处理状态：'success', 'failed', 'partial'
    error_message = db.Column(db.Text, nullable=True)  # 错误信息

    def __repr__(self):
        return f'<DataProcessingStats {self.processing_type}: {self.rows_processed} rows by User {self.user_id} at {self.timestamp}>'

    @staticmethod
    def log_zhiBiao_processing(user_id, file_name, file_path, rows_processed, duration_seconds=None, status='success', error_message=None, details=None):
        """记录ZhiBiao/achieve.py的处理统计"""
        stat = DataProcessingStats(
            user_id=user_id,
            processing_type='zhiBiao_achieve',
            file_name=file_name,
            file_path=file_path,
            rows_processed=rows_processed,
            processing_details=details,
            duration_seconds=duration_seconds,
            status=status,
            error_message=error_message
        )
        db.session.add(stat)
        db.session.commit()
        return stat

    @staticmethod
    def log_TQ_processing(user_id, file_name, file_path, rows_processed, duration_seconds=None, status='success', error_message=None, details=None):
        """记录TQ/tools.py的处理统计"""
        stat = DataProcessingStats(
            user_id=user_id,
            processing_type='TQ_tools',
            file_name=file_name,
            file_path=file_path,
            rows_processed=rows_processed,
            processing_details=details,
            duration_seconds=duration_seconds,
            status=status,
            error_message=error_message
        )
        db.session.add(stat)
        db.session.commit()
        return stat

    @staticmethod
    def log_AI_evaluation(user_id, file_name, file_path, rows_processed, duration_seconds=None, status='success', error_message=None, details=None):
        """记录AI评AI工具的处理统计"""
        stat = DataProcessingStats(
            user_id=user_id,
            processing_type='AI_evaluation',
            file_name=file_name,
            file_path=file_path,
            rows_processed=rows_processed,
            processing_details=details,
            duration_seconds=duration_seconds,
            status=status,
            error_message=error_message
        )
        db.session.add(stat)
        db.session.commit()
        return stat

    @staticmethod
    def get_processing_summary(user_id=None, processing_type=None, start_date=None, end_date=None):
        """获取处理统计摘要"""
        query = DataProcessingStats.query
        
        if user_id:
            query = query.filter_by(user_id=user_id)
        if processing_type:
            query = query.filter_by(processing_type=processing_type)
        if start_date:
            query = query.filter(DataProcessingStats.timestamp >= start_date)
        if end_date:
            query = query.filter(DataProcessingStats.timestamp <= end_date)
            
        stats = query.all()
        
        summary = {
            'total_files': len(stats),
            'total_rows': sum(stat.rows_processed for stat in stats),
            'success_count': len([s for s in stats if s.status == 'success']),
            'failed_count': len([s for s in stats if s.status == 'failed']),
            'total_duration': sum(s.duration_seconds for s in stats if s.duration_seconds),
            'by_type': {}
        }
        
        # 按处理类型分组统计
        for stat in stats:
            ptype = stat.processing_type
            if ptype not in summary['by_type']:
                summary['by_type'][ptype] = {
                    'files': 0,
                    'rows': 0,
                    'success': 0,
                    'failed': 0
                }
            summary['by_type'][ptype]['files'] += 1
            summary['by_type'][ptype]['rows'] += stat.rows_processed
            if stat.status == 'success':
                summary['by_type'][ptype]['success'] += 1
            else:
                summary['by_type'][ptype]['failed'] += 1
                
        return summary