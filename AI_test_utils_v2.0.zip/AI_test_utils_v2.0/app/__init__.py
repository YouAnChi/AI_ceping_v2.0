from flask import Flask
from config import Config
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
from flask_bootstrap import Bootstrap
import logging
from logging.handlers import RotatingFileHandler, TimedRotatingFileHandler
import os
import platform
from datetime import datetime

db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()
login_manager.login_view = 'auth.login' # 指定登录视图的路由
login_manager.login_message_category = 'info' # 设置 flash 消息的类别
bootstrap = Bootstrap()

def setup_improved_logging(app):
    """
    改进的日志配置方案，解决Windows系统权限问题
    
    主要改进：
    1. 使用TimedRotatingFileHandler替代RotatingFileHandler
    2. 添加文件锁检查和重试机制
    3. 支持多种日志存储策略
    4. 增强错误处理
    """
    
    # 获取日志目录
    log_dir = os.path.join(app.instance_path, 'logs')
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # 生成带时间戳的日志文件名
    timestamp = datetime.now().strftime('%Y%m%d')
    log_file = os.path.join(log_dir, f'app_{timestamp}.log')
    
    # 清除现有的处理器
    app.logger.handlers.clear()
    
    try:
        # 方案1：使用TimedRotatingFileHandler（推荐）
        # 按天轮转，保留30天的日志
        handler = TimedRotatingFileHandler(
            log_file,
            when='midnight',
            interval=1,
            backupCount=30,
            encoding='utf-8'
        )
        
        # 设置日志格式
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        handler.setLevel(logging.INFO)
        
        # 添加处理器
        app.logger.addHandler(handler)
        app.logger.setLevel(logging.INFO)
        
        # 记录初始化成功
        app.logger.info(f'改进日志系统初始化成功，日志文件: {log_file}')
        app.logger.info(f'操作系统: {platform.system()}')
        
        return True
        
    except Exception as e:
        # 如果文件日志失败，使用备选方案
        return setup_alternative_logging(app, str(e))

def setup_alternative_logging(app, error_msg=""):
    """
    备选日志方案：使用单一文件 + 手动轮转
    适用于权限受限的环境
    """
    
    log_dir = os.path.join(app.instance_path, 'logs')
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
    
    # 使用固定文件名，避免轮转时的权限问题
    log_file = os.path.join(log_dir, 'app_current.log')
    
    # 清除现有处理器
    app.logger.handlers.clear()
    
    try:
        # 检查文件大小，如果超过限制则手动备份
        if os.path.exists(log_file):
            file_size = os.path.getsize(log_file)
            max_size = 10 * 1024 * 1024  # 10MB
            
            if file_size > max_size:
                # 手动备份
                backup_file = os.path.join(log_dir, f'app_backup_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log')
                try:
                    os.rename(log_file, backup_file)
                except OSError:
                    # 如果重命名失败，尝试复制后删除
                    import shutil
                    shutil.copy2(log_file, backup_file)
                    open(log_file, 'w').close()  # 清空原文件
        
        # 使用普通FileHandler
        handler = logging.FileHandler(log_file, encoding='utf-8')
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        handler.setFormatter(formatter)
        handler.setLevel(logging.INFO)
        
        app.logger.addHandler(handler)
        app.logger.setLevel(logging.INFO)
        
        if error_msg:
            app.logger.warning(f'主日志方案失败({error_msg})，已切换到备选方案')
        app.logger.info(f'备选日志系统初始化成功，日志文件: {log_file}')
        return True
        
    except Exception as e:
        # 最后的备选方案：控制台日志
        console_handler = logging.StreamHandler()
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        console_handler.setFormatter(formatter)
        console_handler.setLevel(logging.INFO)
        app.logger.addHandler(console_handler)
        app.logger.setLevel(logging.INFO)
        
        app.logger.error(f'所有文件日志方案都失败，使用控制台日志: {str(e)}')
        return False

def create_app(config_class=Config):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_class)

    db.init_app(app)
    migrate.init_app(app, db)
    login_manager.init_app(app)
    bootstrap.init_app(app)

    # Define and create UPLOADS_FOLDER if it doesn't exist
    app.config['UPLOADS_FOLDER'] = os.path.join(app.instance_path, 'uploads')
    if not os.path.exists(app.config['UPLOADS_FOLDER']):
        os.makedirs(app.config['UPLOADS_FOLDER'])

    # Define and create PROCESSED_FILES_FOLDER if it doesn't exist
    app.config['PROCESSED_FILES_FOLDER'] = os.path.join(app.instance_path, 'processed_files')
    if not os.path.exists(app.config['PROCESSED_FILES_FOLDER']):
        os.makedirs(app.config['PROCESSED_FILES_FOLDER'])

    # 创建实例文件夹 (如果上面没有创建instance_path的话)
    try:
        os.makedirs(app.instance_path)
    except OSError:
        pass

    # 配置改进的日志系统
    setup_improved_logging(app)
    
    from app.routes import main_bp
    app.register_blueprint(main_bp)

    from app.auth import bp as auth_bp
    app.register_blueprint(auth_bp, url_prefix='/auth')

    # Add timedelta to Jinja2 context
    from datetime import timedelta
    app.jinja_env.globals.update(timedelta=timedelta)
    
    return app

from app import models # 导入 models 模块，确保在 db 对象创建后导入，以便模型能够注册到 SQLAlchemy