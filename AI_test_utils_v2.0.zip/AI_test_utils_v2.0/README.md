# AI测试工具集 v2.0

这是一个用于AI模型测试和评估的工具集，包含数据处理、模型评估和统计分析功能。

## 项目结构

- `TQ/` - 文本抽取和AI提示词处理工具
- `ZhiBiao/` - 指标评估工具，包含多种文本相似度和质量评估方法
- `app/` - Flask Web应用，提供用户界面和数据管理
- `instance/` - 应用实例数据，包含数据库和日志文件
- `migrations/` - 数据库迁移文件

## 数据库表说明

### DataProcessingStats 数据处理统计表

这个表用于记录所有Excel数据处理操作的统计信息，包括：

#### 表字段说明

- `id` - 主键，自增ID
- `user_id` - 关联用户ID（外键关联user表）
- `processing_type` - 处理类型，包括：
  - `zhiBiao_achieve` - ZhiBiao/achieve.py处理的Excel数据
  - `TQ_tools` - TQ/tools.py抽取保存的Excel数据
  - `AI_evaluation` - AI评AI工具处理的Excel数据
- `file_name` - 处理的文件名
- `file_path` - 文件完整路径
- `rows_processed` - 处理的数据行数
- `processing_details` - 处理详情（JSON格式存储额外信息）
- `timestamp` - 处理时间戳
- `duration_seconds` - 处理耗时（秒）
- `status` - 处理状态：'success', 'failed', 'partial'
- `error_message` - 错误信息（如果处理失败）

#### 使用方法

##### 1. 记录ZhiBiao处理统计
```python
from app.models import DataProcessingStats

# 记录ZhiBiao/achieve.py的处理统计
DataProcessingStats.log_zhiBiao_processing(
    user_id=1,
    file_name="test_data.xlsx",
    file_path="/path/to/test_data.xlsx",
    rows_processed=100,
    duration_seconds=45.2,
    status='success',
    details='{"metrics": ["rouge", "bleu"], "model": "gpt-4"}'
)
```

##### 2. 记录TQ工具处理统计
```python
# 记录TQ/tools.py的处理统计
DataProcessingStats.log_TQ_processing(
    user_id=1,
    file_name="extracted_content.xlsx",
    file_path="/path/to/extracted_content.xlsx",
    rows_processed=50,
    duration_seconds=12.5,
    status='success',
    details='{"extraction_type": "count", "count": 50}'
)
```

##### 3. 记录AI评AI工具处理统计
```python
# 记录AI评AI工具的处理统计
DataProcessingStats.log_AI_evaluation(
    user_id=1,
    file_name="ai_evaluation_results.xlsx",
    file_path="/path/to/ai_evaluation_results.xlsx",
    rows_processed=200,
    duration_seconds=120.8,
    status='success',
    details='{"prompt_template": "完整度", "model": "deepseek-v2.5"}'
)
```

##### 4. 获取处理统计摘要
```python
# 获取所有处理统计
summary = DataProcessingStats.get_processing_summary()

# 获取特定用户的统计
user_summary = DataProcessingStats.get_processing_summary(user_id=1)

# 获取特定类型的统计
type_summary = DataProcessingStats.get_processing_summary(processing_type='zhiBiao_achieve')

# 获取时间范围内的统计
from datetime import datetime, timedelta
start_date = datetime.now() - timedelta(days=7)
week_summary = DataProcessingStats.get_processing_summary(start_date=start_date)
```

返回的摘要格式：
```python
{
    'total_files': 150,  # 总处理文件数
    'total_rows': 5000,  # 总处理行数
    'success_count': 145,  # 成功处理数
    'failed_count': 5,   # 失败处理数
    'total_duration': 1200.5,  # 总耗时（秒）
    'by_type': {
        'zhiBiao_achieve': {
            'files': 50,
            'rows': 2000,
            'success': 48,
            'failed': 2
        },
        'TQ_tools': {
            'files': 60,
            'rows': 1500,
            'success': 60,
            'failed': 0
        },
        'AI_evaluation': {
            'files': 40,
            'rows': 1500,
            'success': 37,
            'failed': 3
        }
    }
}
```

## 主要功能模块

### 1. TQ/tools.py - 文本抽取工具

- `extract_and_save_to_excel()` - 从文本文件中随机抽取内容并保存到Excel
- `extract_and_save_to_excel_folder()` - 批量处理文件夹中的文本文件
- `ai_prompt_query()` - 使用AI模型处理提示词转换
- `load_prompts()` - 加载提示词模板
- `analyze_excel()` - 分析Excel中的评分数据

### 2. ZhiBiao/achieve.py - 指标评估工具

- `extract_column_to_new_excel()` - 提取Excel列到新文件
- `query_ai_model_with_excel()` - 使用AI模型处理Excel数据
- `calculate_f1_with_cilin()` - 使用词林计算F1值
- `process_and_evaluate_excel()` - 核心处理和评估函数
- 支持多种评估指标：ASS、ROUGE、BLEU、词林F1等

### 3. Web应用功能

- 用户认证和管理
- 文件上传和处理
- 数据处理统计和监控
- 按钮点击日志记录
- 用户活动日志

## 安装和运行

1. 安装依赖：
```bash
pip install -r requirements.txt
```

2. 初始化数据库：
```bash
flask db upgrade
```

3. 创建管理员用户：
```bash
python create_first_admin.py
```

4. 运行应用：
```bash
python run.py
```

## 注意事项

1. 确保所有Excel文件处理操作都通过相应的统计记录方法进行记录
2. 处理大文件时注意设置合适的超时时间
3. 定期清理过期的日志和临时文件
4. 在生产环境中使用适当的数据库配置

## 更新日志

### v2.0 更新内容
- 新增DataProcessingStats数据处理统计表
- 完善了数据处理的监控和统计功能
- 优化了Excel数据处理流程
- 增强了错误处理和日志记录

## 开发规划

### 可能存在的问题和改进方向

1. **性能优化**
   - 大文件处理时的内存使用优化
   - 数据库查询性能优化
   - 异步处理支持

2. **功能扩展**
   - 更多评估指标的支持
   - 批量处理任务的队列管理
   - 实时处理进度显示

3. **用户体验**
   - 更直观的统计数据可视化
   - 处理结果的导出功能
   - 错误信息的用户友好显示

4. **系统稳定性**
   - 更完善的错误恢复机制
   - 数据备份和恢复功能
   - 系统监控和告警